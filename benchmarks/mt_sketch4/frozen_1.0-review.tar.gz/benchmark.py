"""Read the merged benchmark and score task-local predictions.

The image stream exposes only an image, task ID, class names and opaque sample
index. Ground-truth labels stay in the separate scoring path.
"""
from __future__ import annotations
import argparse
import collections
import json
from pathlib import Path
from PIL import Image, ImageOps


class Benchmark:
    def __init__(self, root=None, stream='balanced_round_robin'):
        self.root = Path(root or Path(__file__).resolve().parent)
        self.records = [json.loads(line) for line in (self.root/'manifest.jsonl').open() if line.strip()]
        self.classes = json.loads((self.root/'metadata/classes.json').read_text())
        streams = json.loads((self.root/'streams.json').read_text())
        if stream not in ('balanced_round_robin','task_blocks'):
            raise ValueError('Unknown stream')
        self.order = streams[stream]
        if sorted(self.order) != list(range(len(self.records))):
            raise ValueError('Stream must visit every image exactly once')
        if len(self.records) != 20000 or collections.Counter(r['task_id'] for r in self.records) != dict.fromkeys(self.classes,5000):
            raise ValueError('Expected four tasks, each containing 5000 images')

    def image_stream(self):
        """Yield images and task metadata without ground-truth class labels."""
        for index in self.order:
            record = self.records[index]
            with Image.open(self.root/record['image_path']) as original:
                image = ImageOps.exif_transpose(original)
                if 'A' in image.getbands() or image.mode=='P' and 'transparency' in image.info:
                    image = Image.alpha_composite(Image.new('RGBA',image.size,'white'),image.convert('RGBA'))
                image = image.convert('RGB').copy()
            yield {'sample_index':index, 'task_id':record['task_id'], 'image':image,
                   'class_names':[entry['class_name'] for entry in self.classes[record['task_id']]]}

    def score(self, predictions):
        """Score exactly one task-local class_index prediction per image.

        The scorer checks membership and labels; it cannot by itself verify
        student-only output or pre-update timing inside a model implementation.
        """
        predictions = list(predictions)
        ids = [p['sample_index'] for p in predictions]
        if len(ids)!=len(self.records) or set(ids)!=set(range(len(self.records))):
            raise ValueError('Need one prediction per image, without duplicates or omissions')
        correct = collections.Counter()
        for prediction in predictions:
            record = self.records[prediction['sample_index']]
            label = prediction['predicted_class_index']
            if type(label) is not int or not 0<=label<len(self.classes[record['task_id']]):
                raise ValueError('Prediction outside this task class space')
            if prediction.get('task_id',record['task_id']) != record['task_id']:
                raise ValueError('Task identity mismatch')
            correct[record['task_id']] += int(label==record['class_index'])
        per_task = {task:{'correct':correct[task],'total':5000,'accuracy_percent':100*correct[task]/5000}
                    for task in self.classes}
        return {'num_scored':len(predictions),'per_task':per_task,
                'macro_accuracy_percent':sum(x['accuracy_percent'] for x in per_task.values())/4}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--stream',choices=['balanced_round_robin','task_blocks'],default='balanced_round_robin')
    parser.add_argument('--predictions',type=Path)
    args=parser.parse_args()
    benchmark=Benchmark(args.root,args.stream)
    if args.predictions:
        with args.predictions.open() as handle:result=benchmark.score(json.loads(line) for line in handle if line.strip())
    else:
        result={'num_images':len(benchmark.records),'stream':args.stream,
                'tasks':{t:{'images':5000,'classes':len(c)} for t,c in benchmark.classes.items()}}
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
